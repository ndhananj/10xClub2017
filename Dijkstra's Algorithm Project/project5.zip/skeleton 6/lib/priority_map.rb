require_relative 'heap2'

class PriorityMap
  def initialize(&prc)
  end

  def [](key)
  end

  def []=(key, value)
  end

  def count
  end

  def empty?
  end

  def extract
  end

  def has_key?(key)
  end

  protected
  attr_accessor :map, :queue

  def insert(key, value)
  end

  def update(key, value)
  end
end
